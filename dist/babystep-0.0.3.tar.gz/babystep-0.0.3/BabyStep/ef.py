import BabyStep as b
print(b.search_bybinary('python','p'))
